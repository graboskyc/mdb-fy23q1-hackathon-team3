exports = async function(changeEvent) {
  
    const docId = changeEvent.documentKey._id;
    const fullDocument = changeEvent.fullDocument;
    
    const img = fullDocument.encoded;
    
    const aws = context.services.get('aws');
    var awsreq = aws.rekognition().DetectText({"Image": {Bytes:img}});
    var res = await awsreq;
    console.log(JSON.stringify(res));
    
};
