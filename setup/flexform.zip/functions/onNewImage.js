exports = function(changeEvent) {
  
    const docId = changeEvent.documentKey._id;
    const fullDocument = changeEvent.fullDocument;
    
    const img = fullDocument.encoded;
    
    var AWS = require('aws-sdk');  
    var creds = new AWS.Credentials('AKIA6IESFAOZYOHWBA6L', 'tExBM34D98VQfIAIfZC5LGNMQFYN0wGjvfbvy', null);
    AWS.config.update({
      region: "us-east-1",
      "accessKeyId": "AKIA6IESFAOZYOHWBA6L", 
      "secretAccessKey": "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"
    });
    
    var rek = new AWS.Rekognition({apiVersion: "2016-06-27"});
    
    const params = {
      "Image": {
        "Bytes":encodeURIComponent(img)
      },
    };
    console.log(JSON.stringify(params));
    rek.detectText(params, function(err, response) {
    if (err) {
      console.log(err, err.stack); // handle error if an error occurred
    } else {
      console.log(response)
      
    } 
  });
    
};
